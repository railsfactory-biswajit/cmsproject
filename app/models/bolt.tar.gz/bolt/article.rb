class Bolt::Article < ActiveRecord::Base
end
